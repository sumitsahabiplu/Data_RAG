ALTER TABLE supplychain.billofmaterial ADD ConvertedDate DATETIME;

UPDATE supplychain.billofmaterial
SET ConvertedDate =str_to_date((effective_from), '%Y-%m-%d');


ALTER TABLE supplychain.billofmaterial ADD ConvertedDate_effectiveto DATETIME;

UPDATE supplychain.billofmaterial
SET ConvertedDate_effectiveto =str_to_date((effective_to), '%Y-%m-%d');


ALTER TABLE supplychain.billofmaterial
RENAME COLUMN ConvertedDate TO ConvertedDate_effectivefrom;

ALTER TABLE supplychain.billofmaterial
DROP COLUMN effective_to,
Drop column effective_from ;


SELECT * FROM supplychain.batchinputlot;

ALTER TABLE supplychain.batchinputlot ADD ConvertedDate_consumption_ts DATETIME;
UPDATE supplychain.batchinputlot
SET ConvertedDate_consumption_ts =STR_TO_DATE(consumption_ts, '%Y-%m-%d %H:%i:%s.%f');

ALTER TABLE supplychain.batchinputlot
Drop column consumption_ts ;

