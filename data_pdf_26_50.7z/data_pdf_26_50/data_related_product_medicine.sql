-- CREATE SCHEMA supplychain;
    CREATE TABLE supplychain.supplier (
        supplier_id varchar(255) PRIMARY KEY,
        gln varchar(255),
        name_supplier varchar(255),
        country varchar(255),
        rating int
    );