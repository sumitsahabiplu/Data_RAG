SELECT * FROM supplychain.product;

ALTER TABLE supplychain.product
ADD product_name VARCHAR(200);


UPDATE supplychain.product
SET product_name = 'Advil Injection 250mg'
WHERE product_id = 'PROD_00001';

UPDATE supplychain.product
SET product_name = 'Aloe Vera Plus Ointment 100mg'
WHERE product_id = 'PROD_00002';

UPDATE supplychain.product
SET product_name = 'Neosporin Ointment 500mg'
WHERE product_id = 'PROD_00003';

UPDATE supplychain.product
SET product_name = 'Tylenol Capsule 10mg'
WHERE product_id = 'PROD_00004';

UPDATE supplychain.product
SET product_name = 'Cipro Capsule 50mg'
WHERE product_id = 'PROD_00005';

UPDATE supplychain.product
SET product_name = 'Bactrim Injection 5mg'
WHERE product_id = 'PROD_00006';

UPDATE supplychain.product
SET product_name = 'Aspirin Tablet 50mg'
WHERE product_id = 'PROD_00007';

UPDATE supplychain.product
SET product_name = 'Hydrocortisone Ointment 5mg'
WHERE product_id = 'PROD_00008';

UPDATE supplychain.product
SET product_name = 'Penicillin Injection 50mg'
WHERE product_id = 'PROD_00009';

UPDATE supplychain.product
SET product_name = 'Bengay Ointment 10mg'
WHERE product_id = 'PROD_00010';

UPDATE supplychain.product
SET product_name = 'Claritin Tablet 10mg'
WHERE product_id = 'PROD_00011';

UPDATE supplychain.product
SET product_name = 'Prozac Injection 500mg'
WHERE product_id = 'PROD_00012';

UPDATE supplychain.product
SET product_name = 'Mucinex Syrup 500mg'
WHERE product_id = 'PROD_00013';

UPDATE supplychain.product
SET product_name = 'Zoloft Injection 100mg'
WHERE product_id = 'PROD_00014';

UPDATE supplychain.product
SET product_name = 'Hydrocodone Ointment 10mg'
WHERE product_id = 'PROD_00015';

UPDATE supplychain.product
SET product_name = 'Motrin Capsule 5mg'
WHERE product_id = 'PROD_00016';

UPDATE supplychain.product
SET product_name = 'Lisinopril Injection 5mg'
WHERE product_id = 'PROD_00017';

UPDATE supplychain.product
SET product_name = 'Lipitor Capsule 10mg'
WHERE product_id = 'PROD_00018';

UPDATE supplychain.product
SET product_name = 'Zyrtec Capsule 10mg'
WHERE product_id = 'PROD_00019';

UPDATE supplychain.product
SET product_name = 'Benadryl Ointment 10mg'
WHERE product_id = 'PROD_00020';

UPDATE supplychain.product
SET product_name = 'Metformin Capsule 500mg'
WHERE product_id = 'PROD_00021';

UPDATE supplychain.product
SET product_name = 'Dulcolax Tablet 100mg'
WHERE product_id = 'PROD_00022';

UPDATE supplychain.product
SET product_name = 'Cortizone Ointment 50mg'
WHERE product_id = 'PROD_00023';

UPDATE supplychain.product
SET product_name = 'Adderall Capsule 5mg'
WHERE product_id = 'PROD_00024';

UPDATE supplychain.product
SET product_name = 'Vicks VapoRub Ointment 500mg'
WHERE product_id = 'PROD_00025';

UPDATE supplychain.product
SET product_name = 'Tussin Syrup 50mg'
WHERE product_id = 'PROD_00026';

UPDATE supplychain.product
SET product_name = 'IcyHot Ointment 50mg'
WHERE product_id = 'PROD_00027';

UPDATE supplychain.product
SET product_name = 'Excedrin Capsule 250mg'
WHERE product_id = 'PROD_00028';

UPDATE supplychain.product
SET product_name = 'Robitussin Syrup 50mg'
WHERE product_id = 'PROD_00029';

UPDATE supplychain.product
SET product_name = 'Alka-Seltzer Tablet 100mg'
WHERE product_id = 'PROD_00030';

UPDATE supplychain.product
SET product_name = 'Prilosec Capsule 250mg'
WHERE product_id = 'PROD_00031';

UPDATE supplychain.product
SET product_name = 'Pepto-Bismol Syrup 5mg'
WHERE product_id = 'PROD_00032';

UPDATE supplychain.product
SET product_name = 'Caltrate Ointment 10mg'
WHERE product_id = 'PROD_00033';

UPDATE supplychain.product
SET product_name = 'Advil Tablet 250mg'
WHERE product_id = 'PROD_00034';

UPDATE supplychain.product
SET product_name = 'Mucinex Syrup 10mg'
WHERE product_id = 'PROD_00035';

UPDATE supplychain.product
SET product_name = 'Ciprodex Capsule 250mg'
WHERE product_id = 'PROD_00036';

UPDATE supplychain.product
SET product_name = 'Neosporin Ointment 100mg'
WHERE product_id = 'PROD_00037';

UPDATE supplychain.product
SET product_name = 'Theraflu Ointment 50mg'
WHERE product_id = 'PROD_00038';

UPDATE supplychain.product
SET product_name = 'Aleve Ointment 250mg'
WHERE product_id = 'PROD_00039';

UPDATE supplychain.product
SET product_name = 'OxyContin Injection 10mg'
WHERE product_id = 'PROD_00040';

UPDATE supplychain.product
SET product_name = 'Crestor Capsule 5mg'
WHERE product_id = 'PROD_00041';

UPDATE supplychain.product
SET product_name = 'Rogaine Syrup 50mg'
WHERE product_id = 'PROD_00042';

UPDATE supplychain.product
SET product_name = 'Gaviscon Syrup 250mg'
WHERE product_id = 'PROD_00043';

UPDATE supplychain.product
SET product_name = 'Celebrex Injection 5mg'
WHERE product_id = 'PROD_00044';

UPDATE supplychain.product
SET product_name = 'Tums Ointment 5mg'
WHERE product_id = 'PROD_00045';

UPDATE supplychain.product
SET product_name = 'Oxycodone Tablet 100mg'
WHERE product_id = 'PROD_00046';

UPDATE supplychain.product
SET product_name = 'Loratadine Tablet 10mg'
WHERE product_id = 'PROD_00047';

UPDATE supplychain.product
SET product_name = 'Hydrocodone Syrup 500mg'
WHERE product_id = 'PROD_00048';

UPDATE supplychain.product
SET product_name = 'Omeprazole Capsule 10mg'
WHERE product_id = 'PROD_00049';

UPDATE supplychain.product
SET product_name = 'Zofran Tablet 10mg'
WHERE product_id = 'PROD_00050';


